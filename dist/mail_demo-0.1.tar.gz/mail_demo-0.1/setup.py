from setuptools import setup

setup(name='mail-demo',version=0.1,
      description='Mail service',url='#',
      author='Zahra',
      author_email='zahra.navaeepour@gmail.com',
      license='MIT',
      packages=['mail_package'],
      zip_safe = False
      )
